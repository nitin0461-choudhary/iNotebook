import React  from 'react'

const About = () => {
  
  
  return (
    <div>
      This is about page
      
    </div>
  )
}

export default About
