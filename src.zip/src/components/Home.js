
//import { BrowserRouter as Router, Routes, Route} from "react-router-dom";
import Notes from  './Notes';
//import AddNote from './AddNote'
// <AddNote/>
const Home = (props) => {
   const {showAlert}=props;
  return (
    <div>
     
      <Notes showAlert={showAlert}/>
    </div>
  )
}

export default Home
