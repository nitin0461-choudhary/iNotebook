const jwt = require('jsonwebtoken');
const JWT_SECRET = "ntinisgoodboy";

const fetchuser = (req, res, next) => {
    // Get the user from the jwt token and add id to req object
    const token = req.header('auth-token');
    if (!token) {
       // console.log("No token provided");
       // console.log(auth-token);
       console.log(token)
        return res.status(401).send({ error: "Please authenticate using a valid token" });
    }
    try {
        //console.log("Verifying token:", token);
        const data = jwt.verify(token, JWT_SECRET);
       // console.log("Token verified. Decoded data:", data);
        req.user = data.user;
        next();
    } catch (error) {
        console.log("JWT verification failed:", error.message);
        res.status(401).send({ error: "Please authenticate using a valid token" });
    }
};

module.exports = fetchuser;
